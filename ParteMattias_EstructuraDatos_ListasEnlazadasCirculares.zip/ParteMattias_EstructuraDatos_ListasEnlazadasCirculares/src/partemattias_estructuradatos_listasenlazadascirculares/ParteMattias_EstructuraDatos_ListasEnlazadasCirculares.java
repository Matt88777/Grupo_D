package partemattias_estructuradatos_listasenlazadascirculares;

import java.util.Scanner;

public class ParteMattias_EstructuraDatos_ListasEnlazadasCirculares {

    public static void main(String[] args) {
        Scanner escaneo = new Scanner(System.in);
        ListaCircular listaCircular = new ListaCircular();
        Pila bodega = new Pila();
        Cola colaPedidos = new Cola();
        ListaDoblementeEnlazada listaDoble = new ListaDoblementeEnlazada();
        int opcion;

        do {
            System.out.println("\nGestión de Listas Circulares en la Farmacia");
            System.out.println("1) Agregar elemento a la lista circular");
            System.out.println("2) Eliminar elemento de la lista circular");
            System.out.println("3) Mostrar todos los elementos de la lista circular");
            System.out.println("4) Agregar producto a la bodega");
            System.out.println("5) Retirar producto de la bodega");
            System.out.println("6) Agregar pedido a la cola");
            System.out.println("7) Atender pedido de la cola");
            System.out.println("8) Agregar elemento a la lista doblemente enlazada");
            System.out.println("9) Mostrar elementos de la lista doblemente enlazada");
            System.out.println("10) Salir");
            System.out.print("Seleccione una opción en la consola: ");
            opcion = escaneo.nextInt();
            escaneo.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del elemento que desea agregar: ");
                    String agregarElemento = escaneo.nextLine();
                    listaCircular.agregar(agregarElemento);
                    break;
                case 2:
                    System.out.print("Ingrese el nombre del elemento que desea eliminar: ");
                    String eliminarElemento = escaneo.nextLine();
                    listaCircular.eliminar(eliminarElemento);
                    break;
                case 3:
                    listaCircular.mostrarElementos();
                    break;
                case 4:
                    System.out.print("Ingrese el nombre del producto a agregar a la bodega: ");
                    String productoBodega = escaneo.nextLine();
                    bodega.agregarArticulo(productoBodega);
                    break;
                case 5:
                    bodega.retirarArticulo();
                    break;
                case 6:
                    System.out.print("Ingrese el nombre del pedido a agregar a la cola: ");
                    String pedidoCola = escaneo.nextLine();
                    colaPedidos.agregarPedido(pedidoCola);
                    break;
                case 7:
                    colaPedidos.atenderPedido();
                    break;
                case 8:
                    System.out.print("Ingrese el nombre del elemento que desea agregar a la lista doblemente enlazada: ");
                    String elementoDoble = escaneo.nextLine();
                    listaDoble.agregar(elementoDoble);
                    break;
                case 9:
                    listaDoble.mostrarElementos();
                    break;
                case 10:
                    System.out.println("Saliendo del sistema de farmacia.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 10);
        escaneo.close();
    }

}
