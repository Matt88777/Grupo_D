package partemattias_estructuradatos_listasenlazadascirculares;

public class NodoCircular {

    private String dato;
    private NodoCircular siguiente;

    public NodoCircular(String dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    public String getDato() {
        return dato;
    }

    public void setDato(String dato) {
        this.dato = dato;
    }

    public NodoCircular getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCircular siguiente) {
        this.siguiente = siguiente;
    }

}
