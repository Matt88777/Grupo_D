package partemattias_estructuradatos_listasenlazadascirculares;

public class ListaCircular {

    private NodoCircular cabeza;

    public ListaCircular() {
        this.cabeza = null;
    }

    public void agregar(String dato) {
        NodoCircular nuevo = new NodoCircular(dato);
        if (cabeza == null) {
            cabeza = nuevo;
            cabeza.setSiguiente(cabeza);
        } else {
            NodoCircular actual = cabeza;
            while (actual.getSiguiente() != cabeza) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
            nuevo.setSiguiente(cabeza);
        }
        System.out.println("Elemento ha agregado a la lista circular" + dato);
    }

    public void eliminar(String dato) {
        if (cabeza == null) {
            System.out.println("La lista circular está vacía.");
            return;
        }
        NodoCircular actual = cabeza;
        NodoCircular anterior = null;
        do {
            if (actual.getDato().equals(dato)) {
                if (anterior == null) {
                    NodoCircular temp = cabeza;
                    while (temp.getSiguiente() != cabeza) {
                        temp = temp.getSiguiente();
                    }
                    if (cabeza.getSiguiente() == cabeza) {
                        cabeza = null;
                    } else {
                        cabeza = cabeza.getSiguiente();
                        temp.setSiguiente(cabeza);
                    }
                } else {
                    anterior.setSiguiente(actual.getSiguiente());
                }
                System.out.println("Elemento eliminado: " + dato);
                return;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        } while (actual != cabeza);
        System.out.println("Elemento no encontrado" + dato);
    }

    public void mostrarElementos() {
        if (cabeza == null) {
            System.out.println("La lista circular está vacía.");
            return;
        }
        NodoCircular actual = cabeza;
        System.out.println("Elementos en la lista circular:");
        do {
            System.out.println("- " + actual.getDato());
            actual = actual.getSiguiente();
        } while (actual != cabeza);
    }

}
