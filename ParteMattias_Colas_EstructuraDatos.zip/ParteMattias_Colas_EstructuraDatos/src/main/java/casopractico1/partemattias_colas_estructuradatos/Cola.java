/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casopractico1.partemattias_colas_estructuradatos;

/**
 *
 * @author estun
 */
public class Cola {
    private Nodoc frente;
    private Nodoc ultimo;
    
    //Cosntru

    public Cola() {
        this.frente = null;
        this.ultimo = null; 
    }
    
    
    
    //gets y sets

    public Nodoc getFrente() {
        return frente;
    }

    public void setFrente(Nodoc frente) {
        this.frente = frente;
    }

    public Nodoc getUltimo() {
        return ultimo;
    }

    public void setUltimo(Nodoc ultimo) {
        this.ultimo = ultimo;
    }
    
    
    //metodos
    
    
    public void agregarPedido(String pedido){
        Nodoc nodo = new Nodoc(pedido);
        
        //Caso1: si la cola esta vacia
        if(ultimo == null){
            frente = nodo;
        
        }else{
            //conectar el ultimo nodo al nuevo
            ultimo.setSiguiente(nodo); 
        }
        ultimo = nodo;
        System.out.println("Pedido atendido: " + pedido);
        
    }
    
    
    public void atenderPedido(){
        //Caso2: la cola ya tiene algo 
        if(frente != null){
            System.out.println("Pedido atendido: " + frente.getDato());
            frente = frente.getSiguiente();
            
            //
            if(frente == null){
                ultimo = null;
            }
   
        }else{
            System.out.println("No se encuentran pedidos en la cola ");
        
        }  
    }
    
    
    public void mostrarPrimerPedido(){
        if(frente != null){
            System.out.println("Primer pedido de la cola: " + frente.getDato());
        }else{
            System.out.println("La cola se encuentra vacia");
        
        }
    }
    
    
    
    public void mostrarTodosPedidos(){
        if(frente != null){
            System.out.println("Todos loos pedidos de la cola: ");
            Nodoc actual = frente;
            
            while(actual != null){
                System.out.println(actual.getDato() + " ");
                actual = actual.getSiguiente();
                 
            }
            System.out.println();
            
        }else{
            System.out.println("La cola se encuentra vacia");
        
        } 
    } 
}
