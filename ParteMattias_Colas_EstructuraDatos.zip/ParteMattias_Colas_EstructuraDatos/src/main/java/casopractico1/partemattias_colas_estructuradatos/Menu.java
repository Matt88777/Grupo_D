/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casopractico1.partemattias_colas_estructuradatos;
import java.util.Scanner;

        
/**
 *
 * @author estun
 */
public class Menu {
    public static void main(String[] args){
        
         Scanner escaneo = new Scanner(System.in);
        Pila bodega = new Pila();
        Cola colaPedidos = new Cola(); // Cola para manejar los pedidos de la farmacia
        int opcion;

        do {
            System.out.println("\nGestión de la Bodega de la Farmacia");
            System.out.println("1) Agregar producto a la bodega");
            System.out.println("2) Retirar producto de la bodega");
            System.out.println("3) Mostrar último producto agregado");
            System.out.println("4) Mostrar todos los productos en la bodega");
            System.out.println("5) Agregar pedido a la cola");
            System.out.println("6) Atender pedido de la cola");
            System.out.println("7) Mostrar primer pedido en la cola");
            System.out.println("8) Mostrar todos los pedidos en la cola");
            System.out.println("9) Salir");
            System.out.print("Seleccione una opción en la consola: ");
            opcion = escaneo.nextInt();
            escaneo.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del artículo que desea guardar: ");
                    String producto = escaneo.nextLine();
                    bodega.agregarArticulo(producto);
                    break;
                case 2:
                    bodega.retirarArticulo();
                    break;
                case 3:
                    bodega.ultimoArticulo();
                    break;
                case 4:
                    bodega.ensennarArticulosAlmacenados();
                    break;
                case 5:
                    System.out.print("Ingrese el nombre del pedido: ");
                    String pedido = escaneo.nextLine();
                    colaPedidos.agregarPedido(pedido);
                    break;
                case 6:
                    colaPedidos.atenderPedido();
                    break;
                case 7:
                    colaPedidos.mostrarPrimerPedido();
                    break;
                case 8:
                    colaPedidos.mostrarTodosPedidos();
                    break;
                case 9:
                    System.out.println("Saliendo del sistema de bodega.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 9);
        escaneo.close();
        
        
        
  
    
    }
    
}
