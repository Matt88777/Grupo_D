package parteallison_estructuradatos_recursividad;

import java.util.Scanner;

public class ParteAllison_EstructuraDatos_Recursividad {

    public static void main(String[] args) {
        Scanner escaneo = new Scanner(System.in);
        ListaCircular listaCircular = new ListaCircular();
        Pila bodega = new Pila();
        Cola colaPedidos = new Cola();
        ListaDoblementeEnlazada listaDoble = new ListaDoblementeEnlazada();
        Recursividad recursividad = new Recursividad();

        int opcion;

        do {System.out.println("Gestión Recursiva de la Farmacia");
            System.out.println("1) Calcular factorial de un número");
            System.out.println("2) Buscar elemento en lista circular");
            System.out.println("3) Imprimir todos los elementos de la pila recursivamente");
            System.out.println("4) Imprimir todos los elementos de la cola recursivamente");
            System.out.println("5) Sumar elementos de la lista doblemente enlazada recursivamente");
            System.out.println("6) Salir");
            System.out.print("Seleccione alguna de las seis opciones");
            opcion=escaneo.nextInt();
            escaneo.nextLine();
            switch (opcion){
                case 1:
                    System.out.print("Ingrese un número para calcular el factorial: ");
                    int numero = escaneo.nextInt();
                    System.out.println("El factorial de " + numero + " es: " + recursividad.factorial(numero));
                    break;
                case 2:
                    System.out.print("Ingrese el elemento a buscar en la lista circular: ");
                    String buscarElemento = escaneo.nextLine();
                    boolean encontrado = recursividad.buscarEnListaCircular(listaCircular.getCabeza(), buscarElemento, listaCircular.getCabeza());
                    System.out.println("Elemento encontrado: " + encontrado);
                    break;
                case 3:
                    System.out.println("Imprimiendo pila recursivamente:");
                    recursividad.imprimirPilaRecursiva(bodega);
                    break;
                case 4:
                    System.out.println("Imprimiendo cola recursivamente:");
                    recursividad.imprimirColaRecursiva(colaPedidos.getFrente());
                    break;
                case 5:
                    System.out.println("La suma de los elementos en la lista doblemente enlazada es: " + recursividad.sumarElementosListaDoble(listaDoble.getCabeza()));
                    break;
                case 6:
                    System.out.println("Saliendo del sistema recursivo de farmacia.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }while (opcion!=6);
        escaneo.close();
    }

}
