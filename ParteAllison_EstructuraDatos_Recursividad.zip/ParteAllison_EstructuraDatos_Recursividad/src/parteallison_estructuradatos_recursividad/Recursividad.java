package parteallison_estructuradatos_recursividad;

class Recursividad {
        public int factorial(int n){
            if (n==0||n==1){
                return 1;
            } return n*factorial(n-1);
        } public boolean buscarEnListaCircular(NodoCircular nodo, String dato, NodoCircular inicio) {
            if(nodo==null){
            return false;
            }
            if (nodo.getDato().equals(dato)){
            return true;
            }
            if(nodo.getSiguiente()==inicio){
            return false;
            }
            return buscarEnListaCircular(nodo.getSiguiente(), dato, inicio);
        } public void imprimirPilaRecursiva(Pila pila){
            if (pila == null) {
                return;
            } pila.ultimoArticulo();
              pila.retirarArticulo();
              imprimirPilaRecursiva(pila);
        } public void imprimirColaRecursiva(Nodoc nodo){
            if (nodo == null) {
                return;
            }System.out.println(nodo.getDato());
            imprimirColaRecursiva(nodo.getSiguiente());
        } public int sumarElementosListaDoble(NodoDoble nodo){
            if (nodo==null){
                return 0;
            } return Integer.parseInt(nodo.getDato())+sumarElementosListaDoble(nodo.getSiguiente());
        }
    }
