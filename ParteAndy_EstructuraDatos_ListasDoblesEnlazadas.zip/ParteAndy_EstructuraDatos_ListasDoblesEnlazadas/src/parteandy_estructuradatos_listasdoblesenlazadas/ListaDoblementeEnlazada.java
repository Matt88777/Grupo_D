package parteandy_estructuradatos_listasdoblesenlazadas;





public class ListaDoblementeEnlazada {

    private NodoDoble cabeza;
    private NodoDoble cola;

    public ListaDoblementeEnlazada() {
        this.cabeza = null;
        this.cola = null;
    }

    // Agregar un elemento al final de la lista
    public void agregar(String dato) {
        NodoDoble nuevo = new NodoDoble(dato);
        if (cabeza == null) {
            cabeza = nuevo;
            cola = nuevo;
        } else {
            cola.setSiguiente(nuevo);
            nuevo.setAnterior(cola);
            cola = nuevo;
        }
        System.out.println("Elemento agregado a la lista: " + dato);
    }

    // Eliminar un elemento por dato
    public void eliminar(String dato) {
        if (cabeza == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        NodoDoble actual = cabeza;
        while (actual != null && !actual.getDato().equals(dato)) {
            actual = actual.getSiguiente();
        }
        if (actual == null) {
            System.out.println("Elemento no encontrado: " + dato);
        } else {
            if (actual == cabeza) {
                cabeza = cabeza.getSiguiente();
                if (cabeza != null) {
                    cabeza.setAnterior(null);
                }
            } else if (actual == cola) {
                cola = cola.getAnterior();
                if (cola != null) {
                    cola.setSiguiente(null);
                }
            } else {
                actual.getAnterior().setSiguiente(actual.getSiguiente());
                actual.getSiguiente().setAnterior(actual.getAnterior());
            }
            System.out.println("Elemento eliminado: " + dato);
        }
    }

    // Mostrar todos los elementos de la lista
    public void mostrarElementos() {
        if (cabeza == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        NodoDoble actual = cabeza;
        System.out.println("Elementos en la lista (orden directo):");
        while (actual != null) {
            System.out.println("- " + actual.getDato());
            actual = actual.getSiguiente();
        }
    }

    // Mostrar todos los elementos en orden inverso
    public void mostrarElementosInverso() {
        if (cola == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        NodoDoble actual = cola;
        System.out.println("Elementos en la lista (orden inverso):");
        while (actual != null) {
            System.out.println("- " + actual.getDato());
            actual = actual.getAnterior();
        }
    }
}
