package parteandy_estructuradatos_listasdoblesenlazadas;

public class ArbolBinario {

    private NodoArbol raiz;

    public ArbolBinario() {
        this.raiz = null;
    }

    public NodoArbol getRaiz() {
        return raiz;
    }

    // Insertar un nodo en el árbol
    public void insertar(int dato) {
        raiz = insertarRecursivo(raiz, dato);
    }

    private NodoArbol insertarRecursivo(NodoArbol nodo, int dato) {
        if (nodo == null) {
            nodo = new NodoArbol(dato);
            return nodo;
        }
        if (dato < nodo.getDato()) {
            nodo.setIzquierdo(insertarRecursivo(nodo.getIzquierdo(), dato));
        } else if (dato > nodo.getDato()) {
            nodo.setDerecho(insertarRecursivo(nodo.getDerecho(), dato));
        }
        return nodo;
    }

    // Recorridos
    public void recorridoInOrden() {
        System.out.println("Recorrido InOrden:");
        recorridoInOrdenRecursivo(raiz);
        System.out.println();
    }

    private void recorridoInOrdenRecursivo(NodoArbol nodo) {
        if (nodo != null) {
            recorridoInOrdenRecursivo(nodo.getIzquierdo());
            System.out.print(nodo.getDato() + " ");
            recorridoInOrdenRecursivo(nodo.getDerecho());
        }
    }

    public void recorridoPreOrden() {
        System.out.println("Recorrido PreOrden:");
        recorridoPreOrdenRecursivo(raiz);
        System.out.println();
    }

    private void recorridoPreOrdenRecursivo(NodoArbol nodo) {
        if (nodo != null) {
            System.out.print(nodo.getDato() + " ");
            recorridoPreOrdenRecursivo(nodo.getIzquierdo());
            recorridoPreOrdenRecursivo(nodo.getDerecho());
        }
    }

    public void recorridoPostOrden() {
        System.out.println("Recorrido PostOrden:");
        recorridoPostOrdenRecursivo(raiz);
        System.out.println();
    }

    private void recorridoPostOrdenRecursivo(NodoArbol nodo) {
        if (nodo != null) {
            recorridoPostOrdenRecursivo(nodo.getIzquierdo());
            recorridoPostOrdenRecursivo(nodo.getDerecho());
            System.out.print(nodo.getDato() + " ");
        }
    }
}
