package parteandy_estructuradatos_listasdoblesenlazadas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner escaneo = new Scanner(System.in);
        ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada();
        ArbolBinario arbol = new ArbolBinario();
        int opcion;

        do {
            System.out.println("\nGestión de Estructuras de Datos");
            System.out.println("1) Operaciones con Lista Doblemente Enlazada");
            System.out.println("2) Operaciones con Árbol Binario");
            System.out.println("3) Salir");
            System.out.print("Seleccione una opción: ");
            opcion = escaneo.nextInt();
            escaneo.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    int opcionLista;
                    do {
                        System.out.println("\nOperaciones con Lista Doblemente Enlazada");
                        System.out.println("1) Agregar elemento a la lista");
                        System.out.println("2) Eliminar elemento de la lista");
                        System.out.println("3) Mostrar todos los elementos de la lista");
                        System.out.println("4) Mostrar todos los elementos de la lista en orden inverso");
                        System.out.println("5) Volver al menú principal");
                        System.out.print("Seleccione una opción: ");
                        opcionLista = escaneo.nextInt();
                        escaneo.nextLine(); // Limpiar buffer

                        switch (opcionLista) {
                            case 1:
                                System.out.print("Ingrese el nombre del elemento que desea agregar: ");
                                String agregarElemento = escaneo.nextLine();
                                lista.agregar(agregarElemento);
                                break;
                            case 2:
                                System.out.print("Ingrese el nombre del elemento que desea eliminar: ");
                                String eliminarElemento = escaneo.nextLine();
                                lista.eliminar(eliminarElemento);
                                break;
                            case 3:
                                lista.mostrarElementos();
                                break;
                            case 4:
                                lista.mostrarElementosInverso();
                                break;
                            case 5:
                                System.out.println("Volviendo al menú principal.");
                                break;
                            default:
                                System.out.println("Opción no válida. Intente de nuevo.");
                        }
                    } while (opcionLista != 5);
                    break;

                case 2:
                    int opcionArbol;
                    do {
                        System.out.println("\nOperaciones con Árbol Binario");
                        System.out.println("1) Insertar elemento");
                        System.out.println("2) Recorrido InOrden");
                        System.out.println("3) Recorrido PreOrden");
                        System.out.println("4) Recorrido PostOrden");
                        System.out.println("5) Volver al menú principal");
                        System.out.print("Seleccione una opción: ");
                        opcionArbol = escaneo.nextInt();

                        switch (opcionArbol) {
                            case 1:
                                System.out.print("Ingrese un número para insertar: ");
                                int dato = escaneo.nextInt();
                                arbol.insertar(dato);
                                System.out.println("Elemento insertado: " + dato);
                                break;
                            case 2:
                                arbol.recorridoInOrden();
                                break;
                            case 3:
                                arbol.recorridoPreOrden();
                                break;
                            case 4:
                                arbol.recorridoPostOrden();
                                break;
                            case 5:
                                System.out.println("Volviendo al menú principal.");
                                break;
                            default:
                                System.out.println("Opción no válida. Intente nuevamente.");
                        }
                    } while (opcionArbol != 5);
                    break;

                case 3:
                    System.out.println("Saliendo del sistema.");
                    break;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 3);

        escaneo.close();
    }
}
