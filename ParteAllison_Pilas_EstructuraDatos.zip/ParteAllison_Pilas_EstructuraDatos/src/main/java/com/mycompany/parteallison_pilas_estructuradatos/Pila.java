/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parteallison_pilas_estructuradatos;

import java.util.ArrayList;

/**
 *
 * @author End User
 */
public class Pila {
    private ArrayList<String> articulos;
    public Pila(){
        articulos = new ArrayList<>();
    }
    public void agregarArticulo(String articulo){
        articulos.add(articulo);
        System.out.println("El articulo guardado es: "+articulo);
    }
    public void retirarArticulo(){
        if (articulos != null){
            String articuloApartado = articulos.remove(articulos.size()-1);
            System.out.println("Articulo apartado de la bodega: "+articuloApartado);
        } else{
            System.out.println("La bodega está vacía, por ahora no hay articulos que pueda apartar");
        }
    }
    public void ultimoArticulo(){
        if (articulos != null){
            System.out.println("Ultimo articulo almacenado: " + articulos.get(articulos.size()-1));
        } else{
            System.out.println("La bodega está vacia.");
        }
    }
    public void ensennarArticulosAlmacenados(){
        if (articulos != null){
            System.out.println("Articulos en la bodega: "+articulos);
        } else{
            System.out.println("La bodega esta vacia.");
    }
  }
}
