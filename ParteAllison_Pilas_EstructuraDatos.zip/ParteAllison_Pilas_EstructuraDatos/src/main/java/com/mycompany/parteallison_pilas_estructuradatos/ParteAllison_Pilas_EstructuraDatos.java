/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parteallison_pilas_estructuradatos;

import java.util.Scanner;

/**
 *
 * @author End User
 */
public class ParteAllison_Pilas_EstructuraDatos {

    public static void main(String[] args) {
        Scanner escaneo=new Scanner(System.in);
        Pilas bodega=new Pilas();
        int opcion;
        do {
            System.out.println("Gestión de la Bodega de la Farmacia");
            System.out.println("1) Agregar producto a la bodega");
            System.out.println("2) Retirar producto de la bodega");
            System.out.println("3) Mostrar último producto agregado");
            System.out.println("4) Mostrar todos los productos en la bodega");
            System.out.println("5) Salir");
            System.out.print("Seleccione una opciones en la consola: ");
            opcion = escaneo.nextInt();
            
            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del articulo que desee guardar");
                    String producto = escaneo.nextLine();
                    bodega.agregarProducto(producto);
                    break;
                case 2:
                    bodega.retirarProducto();
                    break;
                case 3:
                    bodega.mostrarUltimoProducto();
                    break;
                case 4:
                    bodega.mostrarTodosLosProductos();
                    break;
                case 5:
                    System.out.println("Saliendo del sistema de bodega.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 5);
        escaneo.close();
    }
}
