/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parteallison_estructuradatos_listasenlazadasimple;

/**
 *
 * @author End User
 */
public class ListaEnlazada{
    private NodoL cabeza;

    public ListaEnlazada() {
        this.cabeza = null;
    }

    // Agregar un elemento al final de la lista
    public void agregar(String dato) {
        NodoL nuevo = new NodoL(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoL actual = cabeza;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
        }
        System.out.println("Elemento agregado a la lista: " + dato);
    }

    // Eliminar un elemento por dato
    public void eliminar(String dato) {
        if (cabeza == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        if (cabeza.getDato().equals(dato)) {
            cabeza = cabeza.getSiguiente();
            System.out.println("Elemento eliminado: " + dato);
            return;
        }
        NodoL actual = cabeza;
        while (actual.getSiguiente() != null && !actual.getSiguiente().getDato().equals(dato)) {
            actual = actual.getSiguiente();
        }
        if (actual.getSiguiente() == null) {
            System.out.println("Elemento no encontrado: " + dato);
        } else {
            actual.setSiguiente(actual.getSiguiente().getSiguiente());
            System.out.println("Elemento eliminado: " + dato);
        }
    }

    // Mostrar todos los elementos de la lista
    public void mostrarElementos() {
        if (cabeza == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        NodoL actual = cabeza;
        System.out.println("Elementos en la lista:");
        while (actual != null) {
            System.out.println("- " + actual.getDato());
            actual = actual.getSiguiente();
        }
    }
    
}
