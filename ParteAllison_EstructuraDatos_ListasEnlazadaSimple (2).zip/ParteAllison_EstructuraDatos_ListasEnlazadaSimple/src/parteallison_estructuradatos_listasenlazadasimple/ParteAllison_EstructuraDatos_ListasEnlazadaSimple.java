/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parteallison_estructuradatos_listasenlazadasimple;

import java.util.Scanner;

/**
 *
 * @author End User
 */
public class ParteAllison_EstructuraDatos_ListasEnlazadaSimple {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner escaneo = new Scanner(System.in);
        ListaEnlazada lista = new ListaEnlazada();
        int opcion;

        do {
            System.out.println("\nGestión de Listas Enlazadas en la Farmacia");
            System.out.println("1) Agregar elemento a la lista");
            System.out.println("2) Eliminar elemento de la lista");
            System.out.println("3) Mostrar todos los elementos de la lista");
            System.out.println("4) Salir");
            System.out.print("Seleccione una opción en la consola: ");
            opcion = escaneo.nextInt();
            escaneo.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del elemento que desea agregar: ");
                    String agregarElemento = escaneo.nextLine();
                    lista.agregar(agregarElemento);
                    break;
                case 2:
                    System.out.print("Ingrese el nombre del elemento que desea eliminar: ");
                    String eliminarElemento = escaneo.nextLine();
                    lista.eliminar(eliminarElemento);
                    break;
                case 3:
                    lista.mostrarElementos();
                    break;
                case 4:
                    System.out.println("Saliendo del sistema de listas enlazadas.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 4);
        escaneo.close();
    }
    
}
